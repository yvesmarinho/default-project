"""
lib/project.py — Criação de estrutura de pastas e arquivos base.

Parte do scripts/scaffold.py — Enterprise Default Project Template.
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

from .config import (
    DOMAIN_DEFAULT_PROFILES,
    SPECKIT_SYNC_DATE,
    SPECKIT_TRANSVERSAL_PROFILES,
    CreatedItem,
    ProjectConfig,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger(__name__)

# Raiz do template (a-default-project/) deduzida a partir da localização deste módulo
_TEMPLATE_ROOT = Path(__file__).resolve().parent.parent.parent

# ---------------------------------------------------------------------------
# Placeholders e substituição
# ---------------------------------------------------------------------------

PLACEHOLDERS = {
    "{{PROJECT_NAME}}",
    "{{PROJECT_TITLE}}",
    "{{PROJECT_DESCRIPTION}}",
    "{{CREATED_AT}}",
    "{{DOMAIN}}",
    "{{LANGUAGE}}",
    "{{GITHUB_REPO}}",
}


def _apply_placeholders(text: str, config: ProjectConfig) -> str:
    """Substitui todos os placeholders pelo valor real da config."""
    replacements = {
        "{{PROJECT_NAME}}":        config.project_name,
        "{{PROJECT_TITLE}}":       config.project_title,
        "{{PROJECT_DESCRIPTION}}": config.description,
        "{{CREATED_AT}}":          config.created_at,
        "{{DOMAIN}}":              config.domain,
        "{{LANGUAGE}}":            config.language,
        "{{GITHUB_REPO}}":         config.github_repo or "",
    }
    for key, value in replacements.items():
        text = text.replace(key, value)
    return text


# ---------------------------------------------------------------------------
# Templates internos
# ---------------------------------------------------------------------------

_README_MD = """\
# {{PROJECT_TITLE}}

> {{PROJECT_DESCRIPTION}}

**Domínio**: {{DOMAIN}} | **Linguagem**: {{LANGUAGE}}
**Criado em**: {{CREATED_AT}}
{github_section}

---

## 🚀 Início Rápido

```bash
# Instalar dependências
make install-deps

# Iniciar desenvolvimento
make dev
```

## 📚 Documentação

- [Índice](docs/INDEX.md)
- [Tarefas](docs/TODO.md)

## 🏗️ Estrutura

Consulte os [documentos de arquitetura](docs/) para detalhes.
"""

_DOCS_INDEX_MD = """\
# 📚 Índice — {{PROJECT_TITLE}}

**Projeto**: `{{PROJECT_NAME}}`
**Criado em**: {{CREATED_AT}}
**Last Updated**: {{CREATED_AT}}
**Last Session**: N/A

---

## Documentação Principal

| Arquivo | Descrição |
|---------|-----------|
| [README.md](../README.md) | Documentação pública |
| [TODO.md](TODO.md) | Tarefas pendentes |
| [TODAY_ACTIVITIES.md](TODAY_ACTIVITIES.md) | Atividades do dia |

## Sessões de Trabalho

```
SESSIONS/
└── YYYY-MM-DD/
    ├── SESSION_RECOVERY_YYYY-MM-DD.md
    ├── DAILY_ACTIVITIES_YYYY-MM-DD.md
    ├── SESSION_REPORT_YYYY-MM-DD.md
    └── FINAL_STATUS_YYYY-MM-DD.md
```

---

*Gerado por scaffold.py em {{CREATED_AT}}*
"""

_DOCS_TODO_MD = """\
# 📝 TODO — {{PROJECT_TITLE}}

**Last Updated**: {{CREATED_AT}}
**Status**: 🟢 Em andamento

---

## 🟠 Em Progresso

*(nenhum)*

## 🔵 Pendente

- [ ] Configurar estrutura inicial do projeto
- [ ] Adicionar testes unitários
- [ ] Documentar APIs

## ✅ Concluído

- [x] Scaffold inicial gerado ({{CREATED_AT}})
"""

_DOCS_TODAY_ACTIVITIES_MD = """\
# 📅 Atividades — {{PROJECT_TITLE}}

**Data**: {{CREATED_AT}}
**Projeto**: `{{PROJECT_NAME}}`

---

## ⏰ Atividades do Dia

### ✅ Scaffold Inicial Criado

- Projeto `{{PROJECT_NAME}}` inicializado via `uv run scripts/scaffold.py`
- Domínio: {{DOMAIN}} | Linguagem: {{LANGUAGE}}
- Estrutura de pastas criada
- Regras Copilot geradas

---

*Gerado por scaffold.py*
"""

_GITIGNORE = """\
# Segredos e credenciais
.secrets/
*.key
*.pem
*.crt
*.p12
*.pfx
*.jks
*.keystore
secrets/
credentials/
*.credentials
.env
.env.*
!.env.example

# Python
.venv/
venv/
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
*.egg-info/
dist/
build/
.pytest_cache/
.mypy_cache/
.ruff_cache/
htmlcov/
.coverage

# Node.js
node_modules/
npm-debug.log*
.npm

# VS Code
.vscode/*
!.vscode/settings.json
!.vscode/mcp.json
!.vscode/extensions.json

# OS
.DS_Store
Thumbs.db
*.swp
*.swo

# Logs
*.log
logs/
!scripts/logs/.gitkeep
"""

_SECRETS_README = """\
# 🔒 .secrets/ — Arquivos Sensíveis

**NUNCA commitar este diretório.**

Este diretório é ignorado pelo `.gitignore`.

## O que armazenar aqui

| Tipo | Exemplos |
|------|---------|
| Variáveis de ambiente | `.env`, `.env.production` |
| Chaves SSH | `id_rsa`, `*.pem` |
| Tokens de API | `api-tokens.txt` |
| Credenciais cloud | `aws-credentials` |
| Segredos Kubernetes | `kubeconfig` |

## Uso com MCP

Para servidores MCP que precisam de tokens:

```json
"env": {
  "GITHUB_PERSONAL_ACCESS_TOKEN": "${env:GITHUB_PERSONAL_ACCESS_TOKEN}"
}
```

Configure em `.secrets/.env` e carregue no shell antes de iniciar o VS Code.
"""

_SECRETS_SECURITY_MD = """\
# 🔒 Segurança do Diretório .secrets/

## ⚠️ ATENÇÃO: NUNCA COMMITAR ESTE DIRETÓRIO

Este diretório armazena credenciais, tokens e chaves sensíveis.

## 🛡️ Proteções Aplicadas

### 1. Permissões Restritivas
- **chmod 700** (somente proprietário pode ler/escrever/executar)
- Outros usuários não têm acesso
- Configurado automaticamente pelo scaffold

### 2. Exclusão do Git
- `.secrets/` está em `.gitignore` ✅
- Arquivos não são versionados
- Pre-commit hook valida (se ativado)

### 3. Padrões de Arquivos Sensíveis
**Nunca versionar**:
- `.env*` (qualquer variante)
- `*.key`, `*.pem`, `*.crt` (certificados/chaves)
- `*secret*`, `*password*`, `*token*` (padrões de nome)
- `.vault_pass` (Ansible Vault)

## 📝 Boas Práticas

### Armazenar Credenciais
```bash
# Variáveis de ambiente
cat > .secrets/.env << 'EOF'
GITHUB_PERSONAL_ACCESS_TOKEN=ghp_xxxxxxxxxxxxx
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxx
AWS_ACCESS_KEY_ID=AKIAXXXXXXXXXXXXXXXX
AWS_SECRET_ACCESS_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
EOF

# Proteger arquivo
chmod 600 .secrets/.env
```

### Carregar no Shell
```bash
# Antes de abrir VS Code com MCP
source .secrets/.env
code .
```

### Referenciar em .vscode/mcp.json
```json
{
  "servers": {
    "github": {
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${env:GITHUB_PERSONAL_ACCESS_TOKEN}"
      }
    }
  }
}
```

## 🔍 Validação de Segurança

### Verificar Permissões
```bash
ls -la .secrets/
# Deve mostrar: drwx------ (700)
```

### Ativar Pre-Commit Hook (Opcional)
```bash
# Copiar do template
cp .git-hooks/pre-commit.secrets .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit

# Testar
git add .secrets/.env  # Deve FALHAR
```

## 🚨 Checklist de Segurança

- [ ] `.secrets/` tem permissão 700
- [ ] Arquivos sensíveis têm permissão 600
- [ ] `.secrets/` está em `.gitignore`
- [ ] Variáveis carregadas antes do VS Code
- [ ] Credenciais NÃO estão em mcp.json (usar ${env:VAR})
- [ ] Pre-commit hook ativado (recomendado)

## 📚 Documentação Relacionada

- [Secrets Management Best Practices](../docs/SECURITY.md)
- [MCP Server Setup](../docs/README.md)
- [Ansible Vault Guide](../docs/ANSIBLE_VAULT_GUIDE.md) (se aplicável)

---

**Última verificação**: Automatizada via scaffold
**Permissões atuais**: `ls -ld .secrets/` para verificar
"""

_PRE_COMMIT_SECRETS_HOOK = r"""#!/usr/bin/env bash
# Pre-commit hook: Valida que arquivos sensíveis não sejam commitados
# Instalação:
#   cp .git-hooks/pre-commit.secrets .git/hooks/pre-commit
#   chmod +x .git/hooks/pre-commit

set -euo pipefail

# Cores
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🔍 Validando segurança de secrets...${NC}"

# 1. Verificar se .secrets/ está sendo commitado
if git diff --cached --name-only | grep -q '^\.secrets/'; then
    echo -e "${RED}❌ BLOQUEADO: .secrets/ detectado${NC}"
    echo ""
    echo "Arquivos detectados:"
    git diff --cached --name-only | grep '^\.secrets/' | sed 's/^/  - /'
    echo ""
    echo "💡 Solução: remova os arquivos do staging:"
    echo "   git reset HEAD .secrets/"
    exit 1
fi

# 2. Verificar padrões de arquivos sensíveis
SENSITIVE_PATTERNS=(
    '\.env'
    '\.env\.'
    '\*\.key$'
    '\*\.pem$'
    '\*\.crt$'
    'secret'
    'password'
    'token'
    '\.vault_pass'
    'credentials'
    'kubeconfig'
)

BLOCKED_FILES=()
for pattern in "${SENSITIVE_PATTERNS[@]}"; do
    while IFS= read -r file; do
        [[ -n "$file" ]] && BLOCKED_FILES+=("$file")
    done < <(git diff --cached --name-only | grep -iE "$pattern" || true)
done

if [ ${#BLOCKED_FILES[@]} -gt 0 ]; then
    echo -e "${RED}❌ BLOQUEADO: Arquivos sensíveis detectados${NC}"
    echo ""
    echo "Arquivos bloqueados:"
    printf '  - %s\n' "${BLOCKED_FILES[@]}"
    echo ""
    echo "💡 Estes arquivos devem estar em .secrets/"
    exit 1
fi

# 3. Verificar permissões da pasta .secrets/
if [ -d .secrets ]; then
    PERMS=$(stat -c "%a" .secrets 2>/dev/null || \
            stat -f "%A" .secrets 2>/dev/null || echo "000")
    if [ "$PERMS" != "700" ]; then
        echo -e "${YELLOW}⚠️  .secrets/ não tem permissão 700${NC}"
        echo "   Corrigindo automaticamente..."
        chmod 700 .secrets
        echo -e "${GREEN}✅ Permissões corrigidas${NC}"
    fi
fi

echo -e "${GREEN}✅ Validação de secrets OK${NC}"
exit 0
"""

# ---------------------------------------------------------------------------
# READMEs para sub-pastas de docs/ (IMP-61)
# ---------------------------------------------------------------------------

_DOCS_DEBATES_README = """\
# docs/debates/ — Debates Técnicos e de Produto

Armazena debates estruturados sobre decisões importantes do projeto.

## 🎯 Objetivo

Documentar o **processo de decisão** — não apenas o resultado, mas também:
- Alternativas consideradas
- Prós e contras de cada opção
- Contexto da decisão
- Participantes do debate

## 📝 Formato

Use o template de debate (agent `@template-architect` ou manual):

```markdown
# DEBATE: [Título da Questão]

**Data**: YYYY-MM-DD
**Participantes**: @user1, @user2, AI Agent
**Contexto**: [Por que este debate é necessário?]

## Questão Central
[Pergunta clara que precisa ser respondida]

## Alternativas

### Opção A: [Nome]
**Prós**: ...
**Contras**: ...

### Opção B: [Nome]
**Prós**: ...
**Contras**: ...

## Decisão
[Escolha + Justificativa]

## Ações
- [ ] Implementar X
- [ ] Documentar em decisions/
```

## 🔍 Quando usar

- Mudanças de arquitetura significativas
- Escolha entre tecnologias/frameworks
- Decisões que afetam múltiplos times
- Trade-offs complexos

## 📂 Nomenclatura

`DEBATE_[TOPICO]_YYYY-MM-DD.md`

Exemplos:
- `DEBATE_SPEC_DRIVEN_DEVELOPMENT_2026-04-05.md`
- `DEBATE_ESCOLHA_ORM_2026-03-15.md`

## 🔗 Ver também

- [decisions/](../decisions/) — Registro formal de decisões (ADRs)
- [retrospectives/](../retrospectives/) — Aprendizados pós-sprint
"""

_DOCS_DECISIONS_README = """\
# docs/decisions/ — Architecture Decision Records (ADRs)

Registro formal de decisões arquiteturais do projeto.

## 🎯 Objetivo

Documentar **decisões irreversíveis ou caras de reverter** de forma estruturada.

## 📝 Formato ADR

```markdown
# ADR-NNN: [Título da Decisão]

**Status**: Aceita | Proposta | Depreciada | Substituída por ADR-XXX
**Data**: YYYY-MM-DD
**Decisores**: [Quem tomou a decisão]

## Contexto
[Forças em jogo, restrições, requisitos]

## Decisão
[O que foi decidido]

## Consequências
**Positivas**:
- ...

**Negativas**:
- ...

**Riscos**:
- ...

## Alternativas Consideradas
1. [Opção descartada] — [Por que foi rejeitada]
2. ...
```

## 🔍 Quando criar ADR

- Escolha de banco de dados
- Arquitetura de microserviços vs monolito
- Padrões de autenticação
- Estratégia de deployment
- Frameworks principais

## 📂 Nomenclatura

`ADR-NNN-[titulo-kebab-case].md`

Exemplos:
- `ADR-001-escolha-postgresql.md`
- `ADR-002-arquitetura-event-driven.md`

## 🔗 Recursos

- [ADR GitHub](https://adr.github.io/)
- [decisions/](../decisions/) (esta pasta)
- [debates/](../debates/) — Discussões que antecederam a decisão
"""

_DOCS_GUIDES_README = r"""\
# docs/guides/ — Guias e Tutoriais

Documentação how-to e tutoriais passo-a-passo.

## 🎯 Objetivo

Ensinar como realizar tarefas específicas no projeto.

## 📝 Tipos de Guias

### 1. Guias de Setup
- Como configurar ambiente de desenvolvimento
- Como rodar testes localmente
- Como fazer deploy

### 2. Guias de Desenvolvimento
- Como adicionar uma nova feature
- Como escrever testes
- Como fazer code review

### 3. Guias de Troubleshooting
- Problemas comuns e soluções
- Como debugar erros específicos

### 4. Guias de Integração
- Como integrar com serviços externos
- Como usar APIs internas

## 📂 Estrutura sugerida

```
guides/
├── setup/
│   ├── local-development.md
│   └── ci-cd-setup.md
├── development/
│   ├── adding-features.md
│   └── testing-guide.md
└── troubleshooting/
    └── common-issues.md
```

## 📝 Template de Guia

```markdown
# [Nome da Tarefa]

**Objetivo**: [O que você vai aprender]
**Pré-requisitos**: [O que precisa antes]
**Tempo estimado**: X minutos

## Passo 1: [Ação]
[Instruções detalhadas]

\`\`\`bash
# Comandos exemplo
\`\`\`

## Passo 2: [Ação]
...

## Validação
Como verificar que funcionou:
- [ ] Check 1
- [ ] Check 2

## Troubleshooting
**Erro X**: Solução Y
```

## 🔗 Ver também

- [INDEX.md](../INDEX.md) — Índice geral da documentação
- [templates/](../templates/) — Templates reutilizáveis
"""

_DOCS_RETROSPECTIVES_README = """\
# docs/retrospectives/ — Retrospectivas e Lições Aprendidas

Documentação de aprendizados de sprints, incidentes e projetos.

## 🎯 Objetivo

Capturar **lições aprendidas** para melhorar continuamente.

## 📝 Tipos de Retrospectivas

### 1. Retrospectiva de Sprint
Aprendizados do ciclo de desenvolvimento (semanal/quinzenal)

### 2. Post-Mortem de Incidente
Análise de falhas em produção

### 3. Retrospectiva de Projeto
Review ao final de projeto/feature grande

## 📝 Template: Retrospectiva de Sprint

```markdown
# Retrospectiva Sprint NN — YYYY-MM-DD

**Período**: DD/MM a DD/MM
**Participantes**: [Time]

## ✅ O que funcionou bem
- ...

## ⚠️ O que pode melhorar
- ...

## 💡 Insights e Aprendizados
- ...

## 🎯 Ações para próxima sprint
- [ ] Ação 1
- [ ] Ação 2

## 📊 Métricas
- Velocity: X pontos
- Bugs encontrados: Y
- Deploy frequency: Z
```

## 📝 Template: Post-Mortem

```markdown
# Post-Mortem: [Descrição do Incidente]

**Data do incidente**: YYYY-MM-DD HH:MM
**Duração**: X horas
**Severidade**: Critical | High | Medium
**Impacto**: [Quantos usuários afetados]

## Timeline
- HH:MM - Detecção
- HH:MM - Resposta iniciada
- HH:MM - Causa identificada
- HH:MM - Mitigação aplicada
- HH:MM - Resolução completa

## Causa Raiz
[5 Whys ou análise detalhada]

## Ações Corretivas
- [ ] Curto prazo (hoje)
- [ ] Médio prazo (esta semana)
- [ ] Longo prazo (preventivo)

## Lições Aprendidas
1. ...
2. ...
```

## 📂 Nomenclatura

- Sprints: `RETRO_SPRINT_NN_YYYY-MM-DD.md`
- Post-mortems: `POSTMORTEM_[INCIDENTE]_YYYY-MM-DD.md`
- Projetos: `RETRO_[NOME_PROJETO]_YYYY-MM-DD.md`

## 🔗 Ver também

- [debates/](../debates/) — Decisões técnicas
- [SESSIONS/](../SESSIONS/) — Atividades diárias
"""

_DOCS_ARCHITECTURE_README = """\
# docs/architecture/ — Documentação de Arquitetura

Diagramas, visões e documentação estrutural do sistema.

## 🎯 Objetivo

Documentar a **estrutura e organização** do sistema.

## 📝 Conteúdo

### 1. Visões Arquiteturais (C4 Model)

```
architecture/
├── context/          # C4 Level 1: System Context
├── containers/       # C4 Level 2: Container Diagram
├── components/       # C4 Level 3: Component Diagram
└── code/            # C4 Level 4: Code (opcional)
```

### 2. Diagramas

- Arquitetura de alto nível
- Fluxo de dados
- Deployment topology
- Integrações externas

### 3. Documentação Estrutural

- Módulos e responsabilidades
- Padrões arquiteturais adotados
- Boundaries e interfaces

## 📝 Template: Documento de Arquitetura

```markdown
# Arquitetura: [Componente/Sistema]

**Última atualização**: YYYY-MM-DD
**Owner**: [Time/Pessoa]

## Visão Geral
[Descrição de alto nível]

## Componentes Principais
### [Nome do Componente]
- **Responsabilidade**: ...
- **Tecnologia**: ...
- **Dependências**: ...

## Decisões Arquiteturais
Ver ADRs relacionados:
- [ADR-001](../decisions/ADR-001-xxx.md)

## Diagramas
![Diagrama Context](./diagrams/context.png)

## Qualidade e Não-Funcionais
- Escalabilidade: ...
- Segurança: ...
- Performance: ...

## Riscos Arquiteturais
- [Risco] — [Mitigação]
```

## 🛠️ Ferramentas sugeridas

- **Mermaid** — Diagramas em Markdown
- **PlantUML** — UML extensivo
- **Draw.io** — Diagramas gerais
- **C4 Model** — Framework de visualização

## 📂 Estrutura sugerida

```
architecture/
├── README.md (este arquivo)
├── overview.md
├── context-diagram.md
├── api-design.md
├── data-model.md
└── diagrams/
    ├── context.mmd
    ├── containers.mmd
    └── deployment.png
```

## 🔗 Ver também

- [decisions/](../decisions/) — ADRs
- [debates/](../debates/) — Discussões arquiteturais
"""

_DOCS_TEMPLATES_README = """\
# docs/templates/ — Templates Reutilizáveis

Templates de documentos para uso no projeto.

## 🎯 Objetivo

Padronizar documentação com templates prontos.

## 📝 Templates Disponíveis

### Documentação Técnica
- `FEATURE_SPEC_TEMPLATE.md` — Especificação de feature
- `API_DESIGN_TEMPLATE.md` — Design de API
- `DATABASE_SCHEMA_TEMPLATE.md` — Schema de banco de dados

### Processos
- `BUG_REPORT_TEMPLATE.md` — Reporte de bugs detalhado
- `INCIDENT_REPORT_TEMPLATE.md` — Relatório de incidente
- `CHANGE_REQUEST_TEMPLATE.md` — Solicitação de mudança

### Debates e Decisões
- `DEBATE_TEMPLATE.md` — Estrutura de debate
- `ADR_TEMPLATE.md` — Architecture Decision Record

### Guides
- `GUIDE_TEMPLATE.md` — Tutorial passo-a-passo
- `SETUP_GUIDE_TEMPLATE.md` — Guia de configuração

## ✅ Boas Práticas

1. **Copie, não modifique** — Templates são base, crie cópias
2. **Mantenha atualizados** — Review trimestral
3. **Documente mudanças** — Se alterar template, documente por quê

## 🔗 Como usar

```bash
# Copiar template para novo documento
cp docs/templates/FEATURE_SPEC_TEMPLATE.md \
   docs/features/FEAT-123-new-feature.md
```

## 🔗 Ver também

- Todos os outros diretórios de docs/ usam estes templates
"""

_PROJECT_CREATION_SUMMARY = """\
# 📋 Resumo de Criação do Projeto

**Projeto**: `{{PROJECT_NAME}}`
**Título**: {{PROJECT_TITLE}}
**Criado em**: {{CREATED_AT}}
**Template**: Enterprise Default Project Template v1.0.0

---

## 📊 Informações do Projeto

| Propriedade | Valor |
|-------------|-------|
| **Nome** | {{PROJECT_NAME}} |
| **Descrição** | {{PROJECT_DESCRIPTION}} |
| **Domínio** | {{DOMAIN}} |
| **Linguagem** | {{LANGUAGE}} |
| **Repositório** | {{GITHUB_REPO}} |

---

## 📁 Estrutura Criada

```
{{PROJECT_NAME}}/
├── .github/                    # GitHub config (workflows, agents, prompts)
│   ├── agents/                 # SpecKit agents (11 agents)
│   ├── prompts/                # Prompt templates (9 prompts)
│   ├── ISSUE_TEMPLATE/         # Issue forms (3 templates)
│   ├── copilot-instructions.md # Instruções projeto-específicas
│   ├── CODEOWNERS              # Code review assignments
│   └── dependabot.yml          # Dependências automatizadas
├── .secrets/                   # ⚠️  Credenciais (chmod 700, não versionado)
│   ├── README.md               # Guia de uso de secrets
│   └── SECURITY.md             # Práticas de segurança avançadas
├── .specify/                   # SpecKit memory & constitution
│   ├── memory/
│   │   └── constitution.md     # Princípios e práticas do projeto
│   └── templates/
│       └── agent-file-template.md
├── .vscode/                    # VS Code configuration
│   ├── settings.json           # Editor settings
│   ├── mcp.json                # MCP servers (memory, sequential-thinking)
│   ├── extensions.json         # Recommended extensions
│   ├── tasks.json              # Build tasks
│   └── launch.json             # Debug configurations
├── docs/                       # Documentação do projeto
│   ├── architecture/           # Diagramas e C4 Model
│   ├── debates/                # Debates técnicos
│   ├── decisions/              # ADRs (Architecture Decision Records)
│   ├── guides/                 # Tutoriais e how-tos
│   ├── retrospectives/         # Post-mortems e sprints
│   ├── templates/              # Templates reutilizáveis
│   ├── copilot/                # Regras Copilot (.copilot-* symlinks)
│   ├── SESSIONS/               # Diários de sessões de trabalho
│   │   └── YYYY-MM-DD/
│   ├── INDEX.md                # Índice principal
│   ├── TODO.md                 # Tarefas pendentes
│   └── TODAY_ACTIVITIES.md     # Atividades do dia
├── scripts/                    # Scripts utilitários
│   └── load-mcp.sh             # Ativação de MCP servers
├── CHANGELOG.md                # Histórico de mudanças
├── Makefile                    # Comandos de automação
├── objetivo.md                 # Objetivo do projeto
├── mcp-questions.md            # Perguntas de onboarding MCP
├── pyproject.toml              # Config Python (se aplicável)
├── README.md                   # Documentação pública
├── SECURITY.md                 # Política de segurança GitHub
└── .gitignore                  # Arquivos ignorados pelo Git
```

---

## 🎯 Profiles Aplicados

{profiles_section}

---

## 🔧 Git Inicializado

✅ **Repositório Git criado**
- Commit inicial: `chore: scaffold inicial do projeto {{PROJECT_NAME}}`
- Tag: `scaffold-v1.0.0` (marca versão do template)
- Branch: `master`{git_remote_section}

---

## 🚀 Próximos Passos

### 1. Revisar e Personalizar

```bash
# Revisar arquivos principais
cat README.md
cat objetivo.md
cat docs/INDEX.md
cat .specify/memory/constitution.md
```

### 2. Configurar Ambiente

```bash
# Instalar dependências (se aplicável)
make install-deps

# Configurar MCP servers
./scripts/load-mcp.sh
```

### 3. Configurar Secrets

```bash
# Criar variáveis de ambiente
cp .secrets/README.md .secrets/.env.example
# Editar com suas credenciais
vim .secrets/.env
```

### 4. Iniciar Desenvolvimento

```bash
# Ver comandos disponíveis
make help

# Iniciar dev server (se aplicável)
make dev

# Rodar testes (se implementados)
make test
```

### 5. GitHub (se aplicável)

```bash
# Push inicial para GitHub
git push -u origin master --tags

# Configurar branch protection rules no GitHub:
# - Settings → Branches → Add rule
# - Require pull request reviews
# - Require status checks
```

---

## 📚 Comandos Úteis

### Makefile Targets

```bash
make help           # Lista todos os comandos disponíveis
make init           # Inicialização completa
make install-deps   # Instalar dependências
make dev            # Iniciar desenvolvimento
make build          # Build para produção
make test           # Rodar testes
make lint           # Linting de código
make format         # Formatação de código
make clean          # Limpar arquivos gerados
```

### Git Workflow

```bash
# Criar nova feature
git checkout -b NNN-nome-da-feature

# Commit com convenção
git commit -m "feat(escopo): descrição"

# Push e criar PR
git push -u origin NNN-nome-da-feature
```

### Documentação de Sessões

```bash
# Criar nova sessão (data atual)
mkdir -p docs/SESSIONS/$(date +%Y-%m-%d)

# Arquivos recomendados por sessão:
# - SESSION_RECOVERY_YYYY-MM-DD.md   (contexto inicial)
# - DAILY_ACTIVITIES_YYYY-MM-DD.md   (log incremental)
# - SESSION_REPORT_YYYY-MM-DD.md     (relatório final)
# - FINAL_STATUS_YYYY-MM-DD.md       (estado ao encerrar)
```

---

## 🔗 Links Úteis

### Documentação Interna

- [README.md](../README.md) — Documentação pública
- [docs/INDEX.md](INDEX.md) — Índice de documentação
- [docs/TODO.md](TODO.md) — Tarefas pendentes
- [.specify/memory/constitution.md](../.specify/memory/constitution.md) — Princípios do projeto

### SubPastas de Documentação

- [docs/architecture/](architecture/) — Diagramas e visões do sistema
- [docs/decisions/](decisions/) — ADRs (Architecture Decision Records)
- [docs/guides/](guides/) — Tutoriais e how-tos
- [docs/debates/](debates/) — Debates técnicos documentados
- [docs/retrospectives/](retrospectives/) — Post-mortems e lições aprendidas
- [docs/templates/](templates/) — Templates reutilizáveis

### GitHub Copilot

- [.github/copilot-instructions.md](../.github/copilot-instructions.md) — Instruções do projeto
- [.github/agents/](../.github/agents/) — Agentes customizados (SpecKit)
- [.github/prompts/](../.github/prompts/) — Prompts de sessão

### Segurança

- [SECURITY.md](../SECURITY.md) — Política de segurança pública
- [.secrets/SECURITY.md](../.secrets/SECURITY.md) — Práticas avançadas de segurança
- [.git-hooks/pre-commit.secrets](../.git-hooks/pre-commit.secrets) — Hook para prevenir commits de secrets

---

## 🛡️ Recursos de Segurança

✅ **Proteção de Secrets Ativada**
- Diretório `.secrets/` com chmod 700 (acesso restrito)
- `.gitignore` configurado para ignorar credenciais
- Pre-commit hook disponível em `.git-hooks/pre-commit.secrets`

**Ativar hook de segurança:**
```bash
cp .git-hooks/pre-commit.secrets .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

✅ **GitHub Security Files**
- `SECURITY.md` — Política de segurança
- `CODEOWNERS` — Aprovações obrigatórias
- `dependabot.yml` — Atualizações automatizadas
- Workflows: `security-scan.yml`, `dependency-review.yml`

---

## 🤖 SpecKit & GitHub Copilot

### Agentes Disponíveis

| Agente | Uso |
|--------|-----|
| `@session-manager` | Inicialização e gestão de sessões |
| `@speckit.specify` | Criar especificações de features |
| `@speckit.plan` | Planejar implementação |
| `@speckit.tasks` | Gerar tarefas acionáveis |
| `@speckit.implement` | Executar implementação |
| `@speckit.analyze` | Análise de consistência |
| `@speckit.clarify` | Esclarecer requisitos |
| `@speckit.checklist` | Gerar checklists customizadas |
| `@speckit.constitution` | Gerenciar princípios do projeto |
| `@speckit.taskstoissues` | Converter tasks em GitHub issues |
| `@template-architect` | Análise e evolução do template |

### Prompts de Sessão

| Prompt | Quando usar |
|--------|-------------|
| `/session-start-first` | Primeira sessão do projeto |
| `/session-start` | Iniciar nova sessão |
| `/session-end` | Encerrar sessão |

---

## 📖 Convenções do Projeto

### Commits

```
<tipo>(<escopo>): <descrição>

[corpo opcional]

[rodapé opcional]
```

**Tipos**: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

### Branches

- Features: `NNN-nome-da-feature` (número opcional)
- Bugfixes: `fix-descricao-do-bug`
- Hotfixes: `hotfix-descricao`

### Documentação

- Markdown para toda documentação
- Diagramas em `docs/architecture/`
- ADRs em `docs/decisions/`
- Lições aprendidas em `docs/retrospectives/`

---

## 🎉 Projeto Pronto!

Seu projeto foi criado com sucesso usando o **Enterprise Default Project Template v1.0.0**.

**Características principais:**
- ✅ Estrutura completa de diretórios
- ✅ GitHub Copilot configurado (11 agentes + 9 prompts)
- ✅ Segurança avançada (secrets protegidos)
- ✅ Git inicializado (commit + tag)
- ✅ VS Code configurado (MCP, tasks, debug)
- ✅ Documentação organizada (6 sub-pastas)
- ✅ Makefile com comandos úteis

**Suporte e Dúvidas:**
- Consulte `docs/INDEX.md` para orientação
- Use `@session-manager` para iniciar primeira sessão
- Revise `.github/copilot-instructions.md` para regras do projeto

---

*Gerado automaticamente em {{CREATED_AT}}*
"""

# IMP-64: Templates _VSCODE_MCP_JSON e _VSCODE_SETTINGS_JSON removidos.
# Esses arquivos são agora gerados dinamicamente por vscode.py com
# customização por domínio e linguagem.

_MAKEFILE = """\
# Makefile — {{PROJECT_TITLE}}
# Gerado por scaffold.py em {{CREATED_AT}}

.PHONY: help init dev build test lint format clean

## Mostra esta ajuda
help:
\t@grep -E '^## ' Makefile | sed 's/## //'

## [DEPRECATED] — use: uv run scripts/scaffold.py
init:
\t@echo ""
\t@echo " ⚠️  Para criar/configurar o projeto, use diretamente:"
\t@echo "      uv run scripts/scaffold.py"
\t@echo "      python scripts/scaffold.py"
\t@echo ""

## Instala dependências
install-deps:
\t@echo "Instalando dependências..."

## Inicia servidor de desenvolvimento
dev:
\t@echo "Iniciando desenvolvimento..."

## Build de produção
build:
\t@echo "Buildando..."

## Executa testes
test:
\t@echo "Executando testes..."

## Lint do código
lint:
\t@echo "Linting..."

## Formata código
format:
\t@echo "Formatando..."

## Remove arquivos gerados
clean:
\t@rm -rf dist/ build/ __pycache__/ .pytest_cache/ *.egg-info/ .coverage htmlcov/
## Carrega variáveis MCP do .secrets/.env e orienta a abrir o VS Code
mcp:
	@bash scripts/load-mcp.sh"""

_CODE_WORKSPACE = """\
{
  "folders": [
    {
      "path": "."
    }
  ],
  "settings": {
    "editor.formatOnSave": true,
    "editor.rulers": [88, 120],
    "files.trimTrailingWhitespace": true,
    "files.insertFinalNewline": true
  },
  "tasks": {
    "version": "2.0.0",
    "tasks": [
      {
        "label": "make: install-deps",
        "type": "shell",
        "command": "make install-deps",
        "group": "build",
        "problemMatcher": []
      },
      {
        "label": "make: dev",
        "type": "shell",
        "command": "make dev",
        "group": { "kind": "build", "isDefault": true },
        "problemMatcher": []
      },
      {
        "label": "make: build",
        "type": "shell",
        "command": "make build",
        "group": "build",
        "problemMatcher": []
      },
      {
        "label": "make: test",
        "type": "shell",
        "command": "make test",
        "group": { "kind": "test", "isDefault": true },
        "problemMatcher": []
      },
      {
        "label": "make: lint",
        "type": "shell",
        "command": "make lint",
        "group": "test",
        "problemMatcher": []
      },
      {
        "label": "make: format",
        "type": "shell",
        "command": "make format",
        "group": "build",
        "problemMatcher": []
      },
      {
        "label": "make: clean",
        "type": "shell",
        "command": "make clean",
        "group": "build",
        "problemMatcher": []
      }
    ]
  },
  "launch": {
    "version": "0.2.0",
    "configurations": []
  }
}
"""

# ---------------------------------------------------------------------------
# Templates de segurança GitHub (BUG-06)
# ---------------------------------------------------------------------------

_SECURITY_MD = """\
# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| Latest  | :white_check_mark: |

## Reporting a Vulnerability

**DO NOT** open public issues for security vulnerabilities.

Instead, please report them privately:

1. Go to the [Security tab]({{GITHUB_REPO}}/security) of this repository
2. Click "Report a vulnerability"
3. Provide detailed information about the vulnerability

### What to Include

- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if available)

### Response Timeline

- **Initial response**: Within 48 hours
- **Status update**: Within 7 days
- **Fix timeline**: Depends on severity (Critical: 24-48h, High: 1 week, Medium: 2 weeks, Low: 1 month)

## Security Best Practices

This project follows security best practices:

- ✅ Dependency scanning via Dependabot
- ✅ CodeQL analysis on every PR
- ✅ Secret scanning enabled
- ✅ Branch protection rules
- ✅ Required code review

## Security Contacts

For security-related questions, contact: [security contact info]
"""

_CODEOWNERS = """\
# Code Owners
#
# Lines starting with '#' are comments.
# Each line is a file pattern followed by one or more owners.
# Owners can be @username, @org/team-name, or email addresses.
#
# Docs: https://docs.github.com/articles/about-code-owners

# Default owners for everything in the repo
* @OWNER

# Security-related files require security team review
/.github/workflows/security-*.yml @OWNER
/.github/dependabot.yml @OWNER
/SECURITY.md @OWNER

# Infrastructure and deployment
/deploy/ @OWNER
/terraform/ @OWNER
/ansible/ @OWNER
/.github/workflows/ @OWNER

# CI/CD pipelines
/.github/workflows/*.yml @OWNER

# Documentation
/docs/ @OWNER
/*.md @OWNER
"""

_DEPENDABOT_YML = """\
# Dependabot configuration
# Docs: https://docs.github.com/code-security/dependabot/dependabot-version-updates/configuration-options-for-the-dependabot.yml-file

version: 2
updates:
  # GitHub Actions
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
      time: "09:00"
    labels:
      - "dependencies"
      - "github-actions"
    reviewers:
      - "OWNER"
    commit-message:
      prefix: "ci"
      include: "scope"

  # Python (if applicable)
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
      time: "09:00"
    labels:
      - "dependencies"
      - "python"
    reviewers:
      - "OWNER"
    commit-message:
      prefix: "deps"
      include: "scope"
    groups:
      dev-dependencies:
        patterns:
          - "pytest*"
          - "black"
          - "ruff"
          - "mypy"

  # Node.js (if applicable)
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
      time: "09:00"
    labels:
      - "dependencies"
      - "npm"
    reviewers:
      - "OWNER"
    commit-message:
      prefix: "deps"
      include: "scope"
    groups:
      dev-dependencies:
        patterns:
          - "@types/*"
          - "eslint*"
          - "typescript"
"""

_SECURITY_SCAN_YML = """\
name: Security Scan

on:
  push:
    branches: [ main, master, develop ]
  pull_request:
    branches: [ main, master, develop ]
  schedule:
    - cron: '0 6 * * 1'  # Weekly on Mondays at 6 AM UTC

permissions:
  actions: read
  contents: read
  security-events: write

jobs:
  codeql:
    name: CodeQL Analysis
    runs-on: ubuntu-latest

    strategy:
      fail-fast: false
      matrix:
        language: [ 'python', 'javascript' ]

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Initialize CodeQL
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
          queries: security-extended

      - name: Autobuild
        uses: github/codeql-action/autobuild@v3

      - name: Perform CodeQL Analysis
        uses: github/codeql-action/analyze@v3

  secret-scan:
    name: Secret Scanning
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: TruffleHog OSS
        uses: trufflesecurity/trufflehog@main
        with:
          path: ./
          base: ${{ github.event.repository.default_branch }}
          head: HEAD
          extra_args: --debug --only-verified
"""

_DEPENDENCY_REVIEW_YML = """\
name: Dependency Review

on:
  pull_request:
    branches: [ main, master, develop ]

permissions:
  contents: read
  pull-requests: write

jobs:
  dependency-review:
    name: Review Dependencies
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Dependency Review
        uses: actions/dependency-review-action@v4
        with:
          fail-on-severity: moderate
          warn-on-OpenSSF-scorecard-level: 3
          comment-summary-in-pr: always
"""

# ---------------------------------------------------------------------------
# Pastas a criar
# ---------------------------------------------------------------------------

DIRS_TO_CREATE = [
    "docs",
    "docs/SESSIONS",
    "docs/architecture",
    "docs/copilot",
    "docs/debates",
    "docs/decisions",
    "docs/guides",
    "docs/retrospectives",
    "docs/templates",
    ".github",
    ".github/agents",
    ".github/prompts",
    ".github/prompts/domain",
    ".git-hooks",
    ".secrets",
    ".vscode",
    "scripts/lib",
    "scripts/logs",
    "src",
]

# ---------------------------------------------------------------------------
# Arquivos a criar: (caminho relativo, conteúdo_template)
# ---------------------------------------------------------------------------

FILES_TO_CREATE: list[tuple[str, str]] = [
    ("README.md",                  _README_MD),
    ("docs/INDEX.md",              _DOCS_INDEX_MD),
    ("docs/TODO.md",               _DOCS_TODO_MD),
    ("docs/TODAY_ACTIVITIES.md",   _DOCS_TODAY_ACTIVITIES_MD),
    ("docs/architecture/README.md", _DOCS_ARCHITECTURE_README),
    ("docs/debates/README.md",     _DOCS_DEBATES_README),
    ("docs/decisions/README.md",   _DOCS_DECISIONS_README),
    ("docs/guides/README.md",      _DOCS_GUIDES_README),
    ("docs/retrospectives/README.md", _DOCS_RETROSPECTIVES_README),
    ("docs/templates/README.md",   _DOCS_TEMPLATES_README),
    (".gitignore",                 _GITIGNORE),
    (".secrets/README.md",         _SECRETS_README),
    (".secrets/SECURITY.md",       _SECRETS_SECURITY_MD),
    (".git-hooks/pre-commit.secrets", _PRE_COMMIT_SECRETS_HOOK),
    # .vscode/mcp.json e settings.json são gerados dinamicamente por vscode.py (IMP-64)
    ("Makefile",                   _MAKEFILE),
    ("scripts/logs/.gitkeep",      ""),
]


# ---------------------------------------------------------------------------
# Função principal
# ---------------------------------------------------------------------------

def create_structure(config: ProjectConfig) -> list[CreatedItem]:
    """
    Cria a estrutura de pastas e arquivos base do projeto em config.project_path.

    - Pastas já existentes → skipped (sem erro)
    - Arquivos já existentes → skipped (não sobrescreve)
    - Retorna lista de CreatedItem com status de cada operação
    """
    results: list[CreatedItem] = []
    base = config.project_path
    base.mkdir(parents=True, exist_ok=True)

    # 1. Pastas
    for dir_rel in DIRS_TO_CREATE:
        dir_path = base / dir_rel
        if dir_path.exists():
            results.append(CreatedItem(
                path=dir_path, kind="dir", status="skipped",
            ))
        else:
            try:
                dir_path.mkdir(parents=True, exist_ok=True)
                results.append(CreatedItem(
                    path=dir_path, kind="dir", status="created",
                ))
            except OSError as e:
                results.append(CreatedItem(
                    path=dir_path, kind="dir", status="error", message=str(e),
                ))

    # 2. Arquivos
    for file_rel, template in FILES_TO_CREATE:
        file_path = base / file_rel
        if file_path.exists():
            results.append(CreatedItem(
                path=file_path, kind="file", status="skipped",
            ))
            continue
        try:
            # Substitui {{PROJECT_*}} antes de escrever
            content = _prepare_content(template, file_rel, config)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            results.append(CreatedItem(
                path=file_path, kind="file", status="created",
            ))
        except OSError as e:
            results.append(CreatedItem(
                path=file_path, kind="file", status="error", message=str(e),
            ))

    # 3. [nome].code-workspace (nome dinâmico)
    ws_path = base / f"{config.project_name}.code-workspace"
    if ws_path.exists():
        results.append(CreatedItem(path=ws_path, kind="file", status="skipped"))
    else:
        try:
            ws_path.write_text(_CODE_WORKSPACE, encoding="utf-8")
            results.append(CreatedItem(path=ws_path, kind="file", status="created"))
        except OSError as e:
            results.append(CreatedItem(path=ws_path, kind="file", status="error", message=str(e)))

    return results


def _prepare_content(template: str, file_rel: str, config: ProjectConfig) -> str:
    """Aplica placeholders e ajustes especiais (ex: README github section)."""
    if file_rel == "README.md":
        github_section = (
            f"**Repositório**: [{config.github_repo}]({config.github_repo})"
            if config.github_repo
            else ""
        )
        template = template.replace("{github_section}", github_section)
    return _apply_placeholders(template, config)


# ---------------------------------------------------------------------------
# SpecKit — cópia de agents, prompts e perfis de domínio
# ---------------------------------------------------------------------------

def copy_speckit(config: ProjectConfig) -> list[CreatedItem]:
    """
    Copia assets SpecKit do template para o projeto gerado.

    Copia (de _TEMPLATE_ROOT → config.project_path):
      - .github/agents/speckit.*.agent.md
      - .github/prompts/speckit.*.prompt.md
      - .github/prompts/session-*.prompt.md
      - .specify/templates/ (diretório completo)
      - .specify/config.json (se existir)
      - Perfil de domínio principal (DOMAIN_DEFAULT_PROFILES[cfg.domain])
      - Perfis extras selecionados (cfg.extra_profiles)
      - Sempre: SPECKIT_TRANSVERSAL_PROFILES (ex: devops-security)

    Arquivos já existentes no destino são saltados (idempotente).
    """
    results: list[CreatedItem] = []
    errors: list[str] = []
    base = config.project_path  # BUG FIX: usar project_path, não target_dir
    src_root = _TEMPLATE_ROOT

    # --- Padrões glob de arquivos SpecKit a copiar ---
    speckit_globs = [
        (".github/agents",                "*.agent.md"),
        (".github/prompts",               "speckit.*.prompt.md"),
        (".github/prompts",               "session-*.prompt.md"),
        (".github/ISSUE_TEMPLATE",        "*.md"),
        (".github/ISSUE_TEMPLATE",        "*.yml"),
    ]

    for rel_dir, pattern in speckit_globs:
        src_dir = src_root / rel_dir
        if not src_dir.is_dir():
            log.warning("⚠️  Diretório de origem não encontrado: %s", src_dir)
            continue
        for src_file in sorted(src_dir.glob(pattern)):
            dst_file = base / rel_dir / src_file.name
            result = _copy_file(src_file, dst_file)
            if result.status == "error":
                errors.append(str(src_file))
            results.append(result)

    # --- .specify/templates/ (diretório completo) ---
    src_specify = src_root / ".specify" / "templates"
    if src_specify.is_dir():
        for src_file in sorted(src_specify.rglob("*")):
            if src_file.is_file():
                rel = src_file.relative_to(src_root)
                dst_file = base / rel
                result = _copy_file(src_file, dst_file)
                if result.status == "error":
                    errors.append(str(src_file))
                results.append(result)
    else:
        log.warning("⚠️  .specify/templates/ não encontrado em %s", src_root)

    # --- .specify/config.json ---
    src_cfg = src_root / ".specify" / "config.json"
    if src_cfg.is_file():
        dst_cfg = base / ".specify" / "config.json"
        result = _copy_file(src_cfg, dst_cfg)
        if result.status == "error":
            errors.append(str(src_cfg))
        results.append(result)

    # --- Perfis de domínio ---
    # 1) principal (pelo domínio)
    domain_profile = DOMAIN_DEFAULT_PROFILES.get(config.domain)
    if domain_profile:
        result = _copy_domain_profile(src_root, base, domain_profile, errors)
        results.append(result)

    # 2) extras selecionados pelo utilizador (D-21)
    for profile_name in config.extra_profiles:
        if profile_name != domain_profile:  # evita duplicata
            result = _copy_domain_profile(src_root, base, profile_name, errors)
            results.append(result)

    # 3) transversais — sempre copiados (D-20)
    for profile_name in SPECKIT_TRANSVERSAL_PROFILES:
        result = _copy_domain_profile(src_root, base, profile_name, errors)
        results.append(result)

    if errors:
        log.warning("⚠️  %d erro(s) ao copiar SpecKit: %s", len(errors), errors)

    return results


# ---------------------------------------------------------------------------
# Templates de documentação — setup inicial do projeto
# ---------------------------------------------------------------------------

def setup_project_docs(config: ProjectConfig) -> list[CreatedItem]:
    """
    Configura templates de documentação do projeto.

    Operações:
      1. objetivo-manifest-template.yaml → objetivo.yaml (raiz, com placeholders)
      2. mcp-questions-template.yaml → mcp-questions.yaml (raiz)
      3. DAILY_ACTIVITIES.template.md → docs/SESSIONS/<data>/DAILY_ACTIVITIES_<data>.md

    Substituições em objetivo.yaml:
      - CHANGE_ME (project.name) → config.project_name
      - CHANGE_ME (summary) → config.description
      - CHANGE_ME (problem_statement) → config.description
      - Pasta do projeto atualizada

    Arquivos já existentes são saltados (idempotente).

    Ref: BUG-09 (corrigido) — documentado em docs/lembrete.md
    """
    results: list[CreatedItem] = []
    base = config.project_path
    src_root = _TEMPLATE_ROOT
    src_templates = src_root / "docs" / "templates"

    if not src_templates.is_dir():
        log.warning("⚠️  Diretório de origem não encontrado: %s", src_templates)
        return results

    # 1. objetivo.yaml (raiz, com substituições)
    src_objetivo = src_templates / "objetivo-manifest-template.yaml"
    dst_objetivo = base / "objetivo.yaml"
    try:
        if dst_objetivo.exists():
            log.info("⏭️  já existe: objetivo.yaml")
            results.append(CreatedItem(path=dst_objetivo, kind="file", status="skipped"))
        else:
            content = src_objetivo.read_text(encoding="utf-8")
            # Substituir placeholders
            content = content.replace('name: "CHANGE_ME"', f'name: "{config.project_name}"')
            content = content.replace('summary: "CHANGE_ME (1-2 linhas)"', f'summary: "{config.description}"')
            content = content.replace('problem_statement: "CHANGE_ME (qual dor real será resolvida?)"', f'problem_statement: "{config.description}"')
            content = content.replace('team_or_person: "CHANGE_ME"', f'team_or_person: "{config.project_name} team"')
            content = content.replace('- "CHANGE_ME"', f'- "{config.project_name} owner"')

            dst_objetivo.write_text(content, encoding="utf-8")
            log.info("✅ criado: objetivo.yaml")
            results.append(CreatedItem(path=dst_objetivo, kind="file", status="created"))
    except OSError as exc:
        log.warning("⚠️  erro ao criar objetivo.yaml: %s", exc)
        results.append(CreatedItem(path=dst_objetivo, kind="file", status="error", message=str(exc)))

    # 2. mcp-questions.yaml (raiz, cópia direta)
    src_mcp = src_templates / "mcp-questions-template.yaml"
    dst_mcp = base / "mcp-questions.yaml"
    result = _copy_file(src_mcp, dst_mcp)
    results.append(result)

    # 3. DAILY_ACTIVITIES_<data>.md em docs/SESSIONS/<data>/
    session_date = config.created_at[:10]  # YYYY-MM-DD
    session_dir = base / "docs" / "SESSIONS" / session_date
    session_dir.mkdir(parents=True, exist_ok=True)

    src_daily = src_templates / "DAILY_ACTIVITIES.template.md"
    dst_daily = session_dir / f"DAILY_ACTIVITIES_{session_date}.md"
    result = _copy_file(src_daily, dst_daily)
    results.append(result)

    return results


def _copy_domain_profile(
    src_root: Path,
    base: Path,
    profile_name: str,
    errors: list[str],
) -> CreatedItem:
    """Copia um perfil de domínio individual."""
    src_file = src_root / ".github" / "prompts" / "domain" / f"{profile_name}.prompt.md"
    dst_file = base / ".github" / "prompts" / "domain" / f"{profile_name}.prompt.md"
    result = _copy_file(src_file, dst_file)
    if result.status == "error":
        errors.append(str(src_file))
    return result


def _copy_file(src: Path, dst: Path) -> CreatedItem:
    """Copia src → dst com logging. Salta se dst já existe."""
    if dst.exists():
        log.info("⏭️  skipped (já existe): %s", dst)
        return CreatedItem(path=dst, kind="file", status="skipped")
    if not src.exists():
        msg = f"origem não encontrada: {src}"
        log.warning("⚠️  %s", msg)
        return CreatedItem(path=dst, kind="file", status="error", message=msg)
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        log.info("✅ copiado: %s → %s", src.name, dst)
        return CreatedItem(path=dst, kind="file", status="created")
    except OSError as exc:
        log.warning("⚠️  erro ao copiar %s: %s", src, exc)
        return CreatedItem(path=dst, kind="file", status="error", message=str(exc))


# ---------------------------------------------------------------------------
# Constitution — geração do arquivo .specify/memory/constitution.md
# ---------------------------------------------------------------------------

def generate_constitution(config: ProjectConfig) -> CreatedItem:
    """
    Gera .specify/memory/constitution.md no projeto destino.

    Copia o constitution-template.md do template, resolve os placeholders
    padrão e adiciona metadados do projeto no cabeçalho.
    Se o arquivo já existir no destino, salta (idempotente).
    """
    src = _TEMPLATE_ROOT / ".specify" / "templates" / "constitution-template.md"
    dst = config.project_path / ".specify" / "memory" / "constitution.md"

    if dst.exists():
        log.info("⏭️  skipped (já existe): %s", dst)
        return CreatedItem(path=dst, kind="file", status="skipped")

    if not src.exists():
        msg = f"constitution-template.md não encontrado em {src}"
        log.warning("⚠️  %s", msg)
        return CreatedItem(path=dst, kind="file", status="error", message=msg)

    try:
        template_content = src.read_text(encoding="utf-8")

        # Substitui os marcadores de template do SpecKit
        content = template_content.replace("[PROJECT_NAME]", config.project_title)
        content = content.replace("[RATIFICATION_DATE]", config.created_at[:10])
        content = content.replace("[LAST_AMENDED_DATE]", config.created_at[:10])
        content = content.replace("[CONSTITUTION_VERSION]", "1.0.0")

        # Cabeçalho com metadados do scaffold
        header = (
            f"<!-- Gerado por scaffold.py {SPECKIT_SYNC_DATE} | "
            f"Domínio: {config.domain} | Linguagem: {config.language} -->\n"
        )
        content = header + content

        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(content, encoding="utf-8")
        log.info("✅ constitution.md gerado: %s", dst)
        return CreatedItem(path=dst, kind="file", status="created")
    except OSError as exc:
        log.warning("⚠️  erro ao gerar constitution.md: %s", exc)
        return CreatedItem(path=dst, kind="file", status="error", message=str(exc))


# ---------------------------------------------------------------------------
# MCP env vars required per domain (mirrors vscode._MCP_BY_DOMAIN "env" fields)
# ---------------------------------------------------------------------------

_MCP_ENV_VARS_BY_DOMAIN: dict[str, list[str]] = {
    "programming":    ["GITHUB_PERSONAL_ACCESS_TOKEN"],
    "infrastructure": ["GITHUB_PERSONAL_ACCESS_TOKEN"],
    "analysis":       ["BRAVE_API_KEY"],
}


# ---------------------------------------------------------------------------
# load-mcp.sh — geração dinâmica por domínio
# ---------------------------------------------------------------------------

def generate_load_mcp(config: ProjectConfig) -> CreatedItem:
    """
    Gera scripts/load-mcp.sh com as variáveis de ambiente obrigatórias para o domínio.

    - Verifica .secrets/.env; orienta o usuário se ausente
    - Carrega as variáveis (set -a; source; set +a)
    - Valida variáveis obrigatórias pelo domínio
    - Verifica presença de npx e node
    - Imprime instrução para abrir o VS Code
    - Idempotente — skip se scripts/load-mcp.sh já existe
    """
    dest = config.project_path / "scripts" / "load-mcp.sh"
    if dest.exists():
        return CreatedItem(path=dest, kind="file", status="skipped", message="já existe")

    required_vars = _MCP_ENV_VARS_BY_DOMAIN.get(config.domain, [])

    # Bloco de exemplo para .secrets/.env
    example_lines = "\n".join(
        f"   {var}=your-value-here" for var in required_vars
    ) or "   (nenhuma variável requerida para este domínio)"

    # Bloco de validação de variáveis
    validation_lines = "\n".join(
        f'  [[ -z "${{{var}:-}}" ]] && MISSING+=("{var}")'
        for var in required_vars
    ) or "  # nenhuma variável requerida para este domínio"

    script = (
        "#!/usr/bin/env bash\n"
        "# load-mcp.sh — Carrega variáveis de ambiente para MCP Servers\n"
        f"# Domínio: {config.domain}\n"
        "# Gerado por scaffold.py — NÃO commitar este script com tokens reais\n"
        "#\n"
        "# Uso:\n"
        "#   bash scripts/load-mcp.sh\n"
        "#   make mcp\n"
        "set -euo pipefail\n"
        "\n"
        'SECRETS_ENV=".secrets/.env"\n'
        "\n"
        'if [[ ! -f "$SECRETS_ENV" ]]; then\n'
        '  echo "⚠️  .secrets/.env não encontrado."\n'
        '  echo "   Crie o arquivo com os tokens necessários:"\n'
        '  echo ""\n'
        '  echo "   # .secrets/.env"\n'
        f'  echo "{example_lines}"\n'
        '  echo ""\n'
        '  exit 1\n'
        "fi\n"
        "\n"
        "# Carrega sem poluir o histórico do shell\n"
        "set -a; source \"$SECRETS_ENV\"; set +a\n"
        "\n"
        "# Valida variáveis obrigatórias\n"
        "MISSING=()\n"
        + validation_lines + "\n"
        "\n"
        "if [[ ${#MISSING[@]} -gt 0 ]]; then\n"
        '  echo "❌ Variáveis obrigatórias ausentes em $SECRETS_ENV:"\n'
        "  printf '   %s\\n' \"${MISSING[@]}\"\n"
        "  exit 1\n"
        "fi\n"
        "\n"
        "# Verifica dependências de runtime\n"
        "for cmd in npx node; do\n"
        '  if ! command -v "$cmd" &>/dev/null; then\n'
        '    echo "❌ Dependência ausente: $cmd"\n'
        '    echo "   Instale o Node.js: https://nodejs.org/"\n'
        "    exit 1\n"
        "  fi\n"
        "done\n"
        "\n"
        'echo "✅ Ambiente MCP carregado com sucesso."\n'
        'echo ""\n'
        'echo "   Abra o VS Code com:"\n'
        'echo "   code ."\n'
    )

    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(script, encoding="utf-8")
        # Torna executável: rwxr-xr-x (0o755)
        os.chmod(dest, 0o755)
        log.info("✅ load-mcp.sh gerado: %s", dest)
        return CreatedItem(path=dest, kind="file", status="created")
    except OSError as exc:
        log.warning("⚠️  erro ao gerar load-mcp.sh: %s", exc)
        return CreatedItem(path=dest, kind="file", status="error", message=str(exc))


# ---------------------------------------------------------------------------
# Secrets Security Setup (IMP-60)
# ---------------------------------------------------------------------------

def setup_secrets_security(config: ProjectConfig) -> list[CreatedItem]:
    """
    Configura proteção avançada para .secrets/ directory.

    Implementa:
      - chmod 700 em .secrets/ (somente proprietário tem acesso)
      - .secrets/SECURITY.md já foi criado em FILES_TO_CREATE
      - .git-hooks/pre-commit.secrets template já foi criado
      - Valida que .secrets/ está no .gitignore

    Esta função é chamada APÓS create_structure(), garantindo que:
      1. .secrets/ já existe
      2. Arquivos de documentação já foram criados
      3. Aplicamos permissões restritivas

    Retorna lista de ações realizadas (permissões modificadas, validações).

    Ref: IMP-60 — documentado em docs/lembrete.md
    """
    results: list[CreatedItem] = []
    base = config.project_path
    secrets_dir = base / ".secrets"

    # 1. Verificar que .secrets/ existe
    if not secrets_dir.exists():
        msg = ".secrets/ não existe ainda — pulando setup de segurança"
        log.warning("⚠️  %s", msg)
        return results

    # 2. Aplicar chmod 700 (rwx------)
    try:
        current_perms = secrets_dir.stat().st_mode & 0o777
        if current_perms != 0o700:
            secrets_dir.chmod(0o700)
            log.info("🔒 .secrets/ protegido: chmod 700 aplicado")
            results.append(CreatedItem(
                path=secrets_dir,
                kind="dir",
                status="secured",
                message="chmod 700 aplicado"
            ))
        else:
            log.info("✅ .secrets/ já tem permissão 700")
            results.append(CreatedItem(
                path=secrets_dir,
                kind="dir",
                status="skipped",
                message="permissões já corretas (700)"
            ))
    except OSError as exc:
        log.warning("⚠️  erro ao aplicar chmod 700: %s", exc)
        results.append(CreatedItem(
            path=secrets_dir,
            kind="dir",
            status="error",
            message=f"chmod falhou: {exc}"
        ))

    # 3. Validar .gitignore contém .secrets/
    gitignore = base / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        if ".secrets/" in content:
            log.info("✅ .gitignore contém .secrets/")
            results.append(CreatedItem(
                path=gitignore,
                kind="validation",
                status="ok",
                message=".secrets/ está ignorado no git"
            ))
        else:
            log.warning("⚠️  .secrets/ NÃO está em .gitignore!")
            results.append(CreatedItem(
                path=gitignore,
                kind="validation",
                status="warning",
                message=".secrets/ ausente no .gitignore"
            ))

    # 4. Informar sobre pre-commit hook (opcional)
    hook_template = base / ".git-hooks" / "pre-commit.secrets"
    if hook_template.exists():
        log.info("💡 Pre-commit hook disponível")
        log.info("   cp .git-hooks/pre-commit.secrets ")
        log.info("      .git/hooks/pre-commit")
        log.info("   chmod +x .git/hooks/pre-commit")
        results.append(CreatedItem(
            path=hook_template,
            kind="file",
            status="available",
            message="pre-commit hook criado (ativar manualmente)"
        ))

    return results


# ---------------------------------------------------------------------------
# GitHub Security Files (BUG-06)
# ---------------------------------------------------------------------------

def generate_github_security_files(config: ProjectConfig) -> list[CreatedItem]:
    """
    Gera arquivos de segurança GitHub no projeto.

    Cria:
      - SECURITY.md (política de reporte de vulnerabilidades)
      - .github/CODEOWNERS (ownership de código)
      - .github/dependabot.yml (atualizações automáticas)
      - .github/workflows/security-scan.yml (CodeQL + secret scan)
      - .github/workflows/dependency-review.yml (análise de dependências em PRs)

    OWNER placeholder é substituído pelo dono do repo GitHub (se disponível).

    Ref: BUG-06 — documentado em docs/lembrete.md
    """
    results: list[CreatedItem] = []
    base = config.project_path

    # Extrair owner do github_repo (ex: https://github.com/user/repo → user)
    owner = "OWNER"
    if config.github_repo:
        parts = config.github_repo.rstrip("/").split("/")
        if len(parts) >= 2:
            owner = f"@{parts[-2]}"

    # Arquivo 1: SECURITY.md (raiz do projeto)
    security_md = base / "SECURITY.md"
    content = _apply_placeholders(_SECURITY_MD, config)
    results.append(_write_file(security_md, content))

    # Arquivo 2: .github/CODEOWNERS
    codeowners = base / ".github" / "CODEOWNERS"
    content = _CODEOWNERS.replace("@OWNER", owner)
    results.append(_write_file(codeowners, content))

    # Arquivo 3: .github/dependabot.yml
    dependabot = base / ".github" / "dependabot.yml"
    content = _DEPENDABOT_YML.replace("OWNER", owner.lstrip("@"))
    results.append(_write_file(dependabot, content))

    # Arquivo 4: .github/workflows/security-scan.yml
    security_scan = base / ".github" / "workflows" / "security-scan.yml"
    results.append(_write_file(security_scan, _SECURITY_SCAN_YML))

    # Arquivo 5: .github/workflows/dependency-review.yml
    dependency_review = base / ".github" / "workflows" / "dependency-review.yml"
    results.append(_write_file(dependency_review, _DEPENDENCY_REVIEW_YML))

    return results


def generate_project_creation_summary(config: ProjectConfig) -> CreatedItem:
    """
    Gera docs/PROJECT_CREATION_SUMMARY.md com resumo completo da criação.

    Contém:
      - Informações do projeto (nome, descrição, domínio, linguagem)
      - Estrutura de diretórios criada
      - Profiles aplicados
      - Status do Git (commit, tag, remote)
      - Próximos passos recomendados
      - Comandos úteis (Makefile, Git, Docs)
      - Links para documentação interna
      - Recursos de segurança
      - Agentes e prompts SpecKit disponíveis
      - Convenções do projeto

    Ref: IMP-63 — Feature documentada em docs/lembrete.md
    """
    summary_path = config.project_path / "docs" / "PROJECT_CREATION_SUMMARY.md"

    if summary_path.exists():
        log.info("⏭️  já existe: %s", summary_path.name)
        return CreatedItem(path=summary_path, kind="file", status="skipped")

    # Construir seção de profiles aplicados
    profiles = []
    # Adicionar profile padrão do domínio
    if config.domain in DOMAIN_DEFAULT_PROFILES:
        # DOMAIN_DEFAULT_PROFILES é dict[str, str], não list!
        profiles.append(DOMAIN_DEFAULT_PROFILES[config.domain])
    # Adicionar profiles transversais (aplicados sempre)
    profiles.extend(SPECKIT_TRANSVERSAL_PROFILES)
    # Adicionar profiles extras (se fornecidos)
    if config.extra_profiles:
        if isinstance(config.extra_profiles, str):
            # Se for string, fazer split por vírgula
            extra = [p.strip() for p in config.extra_profiles.split(",") if p.strip()]
            profiles.extend(extra)
        elif isinstance(config.extra_profiles, list):
            profiles.extend(config.extra_profiles)

    # Remover duplicatas mantendo ordem
    seen = set()
    unique_profiles = []
    for p in profiles:
        if p not in seen:
            seen.add(p)
            unique_profiles.append(p)

    if unique_profiles:
        profiles_section = "**Profiles aplicados:**\n"
        for profile in unique_profiles:
            profiles_section += f"- ✅ `{profile}`\n"
    else:
        profiles_section = "*Nenhum profile específico aplicado.*\n"

    # Seção de remote Git (se configurado)
    git_remote_section = ""
    if config.github_repo:
        git_remote_section = f"\n- Remote: `origin` → {config.github_repo}"

    # Aplicar placeholders
    content = _apply_placeholders(_PROJECT_CREATION_SUMMARY, config)
    content = content.replace("{profiles_section}", profiles_section)
    content = content.replace("{git_remote_section}", git_remote_section)

    return _write_file(summary_path, content)


def _write_file(path: Path, content: str) -> CreatedItem:
    """Escreve arquivo com conteúdo, criando diretórios necessários."""
    try:
        if path.exists():
            log.info("⏭️  já existe: %s", path.name)
            return CreatedItem(path=path, kind="file", status="skipped")

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        log.info("✅ criado: %s", path.name)
        return CreatedItem(path=path, kind="file", status="created")
    except OSError as exc:
        log.warning("⚠️  erro ao criar %s: %s", path.name, exc)
        return CreatedItem(path=path, kind="file", status="error", message=str(exc))


# ---------------------------------------------------------------------------
# Scaffold state — persiste e recupera configuração do projeto gerado
# ---------------------------------------------------------------------------

_STATE_FILENAME = ".scaffold-state.yaml"


def write_scaffold_state(
    config: ProjectConfig,
    profiles_applied: list[str] | None = None,
) -> CreatedItem:
    """
    Persiste o estado do projeto em <target_dir>/.scaffold-state.yaml.

    Chamado ao final de flow_new_project e de flow_compose_profiles para que
    o fluxo de upgrade saiba quais perfis foram aplicados e com qual config
    o projeto foi criado.

    O arquivo é SEMPRE sobrescrito (não é idempotente como os demais).

    IMP-65 Fase 1: Agora também armazena template_versions para tracking de drift.
    """
    from datetime import datetime, timezone

    state_path = config.project_path / _STATE_FILENAME

    # Carrega estado anterior (se existir) para preservar created_at e profiles
    existing_profiles: list[str] = []
    original_created_at: str = config.created_at
    if state_path.exists():
        try:
            import yaml
            with state_path.open(encoding="utf-8") as f:
                old = yaml.safe_load(f) or {}
            existing_profiles = old.get("profiles_applied", [])
            original_created_at = old.get("created_at", config.created_at)
        except Exception:
            pass

    # Merge: adiciona novos perfis sem duplicar
    merged_profiles = list(existing_profiles)
    for p in (profiles_applied or []):
        if p not in merged_profiles:
            merged_profiles.append(p)

    # IMP-65 Fase 1: Scan current template versions
    template_versions = {}
    template_dir = config.project_path / ".specify" / "templates"
    if template_dir.exists():
        try:
            from . import template_version
            templates = template_version.scan_templates(template_dir)
            template_versions = {
                name: info.version
                for name, info in templates.items()
            }
        except Exception as exc:
            log.warning("⚠️  Failed to scan template versions: %s", exc)

    state: dict = {
        "scaffold_version": "1.0.0",
        "created_at": original_created_at,
        "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "project": {
            "name":        config.project_name,
            "title":       config.project_title,
            "description": config.description,
            "domain":      config.domain,
            "language":    config.language,
            "github_repo": config.github_repo or "",
        },
        "paths": {
            "target_dir": str(config.target_dir),
            "shared_dir": str(config.shared_dir),
        },
        "profiles_applied": merged_profiles,
        "template_versions": template_versions,  # IMP-65 Fase 1
    }

    try:
        import yaml
        state_path.write_text(
            yaml.dump(state, allow_unicode=True, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
        log.info("✅ scaffold state gravado: %s", state_path)
        return CreatedItem(path=state_path, kind="file", status="created")
    except Exception as exc:
        log.warning("⚠️  erro ao gravar scaffold state: %s", exc)
        return CreatedItem(path=state_path, kind="file", status="error", message=str(exc))


def read_scaffold_state(target_dir: Path) -> dict | None:
    """
    Lê <target_dir>/.scaffold-state.yaml e retorna o dict com o estado.
    Retorna None se o arquivo não existe ou está corrompido.
    """
    state_path = target_dir / _STATE_FILENAME
    if not state_path.exists():
        return None
    try:
        import yaml
        with state_path.open(encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return data if isinstance(data, dict) else None
    except Exception as exc:
        log.warning("⚠️  erro ao ler scaffold state: %s", exc)
        return None


def config_from_state(state: dict, override_target: Path | None = None) -> ProjectConfig:
    """
    Reconstrói um ProjectConfig a partir do estado salvo.

    Args:
        state:           dict retornado por read_scaffold_state()
        override_target: se fornecido, sobrescreve paths.target_dir do state
                        No modo upgrade, override_target é o próprio projeto.
    """
    from datetime import datetime, timezone

    proj = state.get("project", {})
    paths = state.get("paths", {})
    project_name = proj.get("name", "unknown")

    # Correção IMP-47: detectar se override_target é o próprio projeto
    if override_target:
        # Se override_target termina com o nome do projeto,
        # então está apontando para o projeto, não para o diretório pai
        if override_target.name == project_name:
            target = override_target.parent
        else:
            # Fallback: assume que override_target é o diretório pai
            target = override_target
    else:
        # Modo normal: usa target_dir do state
        target = Path(paths.get("target_dir", "."))

    shared = Path(paths.get("shared_dir", str(
        Path.home() / "Documentos" / "DevOps" / ".copilot-shared"
    )))

    return ProjectConfig(
        project_name=project_name,
        project_title=proj.get("title", proj.get("name", "Unknown")),
        description=proj.get("description", ""),
        domain=proj.get("domain", "programming"),
        language=proj.get("language", "python"),
        github_repo=proj.get("github_repo") or None,
        shared_dir=shared,
        target_dir=target,
        created_at=state.get("created_at", datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")),
        extra_profiles=state.get("profiles_applied", []),
    )
